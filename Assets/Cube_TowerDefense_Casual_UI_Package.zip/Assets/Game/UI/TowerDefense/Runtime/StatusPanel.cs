using TMPro;
using UnityEngine;

namespace Game
{
    public sealed class StatusPanel : MonoBehaviour
    {
        [SerializeField] private UIProgressBar baseLifeBar;
        [SerializeField] private TMP_Text goldText;
        [SerializeField] private TMP_Text waveText;
        [SerializeField] private TMP_Text enemyText;

        public void SetBaseLife(int current, int max)
        {
            if (baseLifeBar != null)
            {
                baseLifeBar.SetValue(current, max);
            }
        }

        public void SetGold(int gold)
        {
            if (goldText != null)
            {
                goldText.text = gold.ToString();
            }
        }

        public void SetWave(int currentWave, int totalWave)
        {
            if (waveText != null)
            {
                waveText.text = $"第 {currentWave}/{totalWave} 波";
            }
        }

        public void SetEnemyCount(int alive, int total)
        {
            if (enemyText != null)
            {
                enemyText.text = $"{alive}/{total}";
            }
        }
    }
}
