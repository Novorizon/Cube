using System;
using System.Collections.Generic;
using UnityEngine;

namespace Game
{
    public sealed class BuildTowerPanel : MonoBehaviour
    {
        [SerializeField] private RectTransform contentRoot;
        [SerializeField] private TowerBuildCardView cardPrefab;

        private readonly List<TowerBuildCardView> cards = new List<TowerBuildCardView>();
        private int selectedTowerId;

        public event Action<int> TowerClicked;

        public void Build(IReadOnlyList<TdTowerUiConfig> configs)
        {
            Clear();
            if (contentRoot == null || cardPrefab == null || configs == null)
            {
                return;
            }
            for (int i = 0; i < configs.Count; i++)
            {
                TowerBuildCardView card = Instantiate(cardPrefab, contentRoot);
                card.Init(configs[i], OnTowerClicked);
                cards.Add(card);
            }
        }

        public void SetSelectedTower(int towerId)
        {
            selectedTowerId = towerId;
            for (int i = 0; i < cards.Count; i++)
            {
                cards[i].SetSelected(cards[i] != null && cards[i].gameObject.activeSelf && cards[i].TowerId == selectedTowerId);
            }
        }

        public void ClearSelected()
        {
            selectedTowerId = 0;
            for (int i = 0; i < cards.Count; i++)
            {
                cards[i].SetSelected(false);
            }
        }

        private void OnTowerClicked(int towerId)
        {
            selectedTowerId = towerId;
            for (int i = 0; i < cards.Count; i++)
            {
                cards[i].SetSelected(cards[i].TowerId == towerId);
            }
            TowerClicked?.Invoke(towerId);
        }

        private void Clear()
        {
            for (int i = 0; i < cards.Count; i++)
            {
                if (cards[i] != null)
                {
                    Destroy(cards[i].gameObject);
                }
            }
            cards.Clear();
        }
    }
}
