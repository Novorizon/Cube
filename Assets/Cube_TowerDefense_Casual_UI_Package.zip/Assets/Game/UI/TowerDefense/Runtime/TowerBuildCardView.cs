using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Game
{
    public sealed class TowerBuildCardView : MonoBehaviour
    {
        [SerializeField] private Button button;
        [SerializeField] private Image iconImage;
        [SerializeField] private Image selectedFrame;
        [SerializeField] private TMP_Text nameText;
        [SerializeField] private TMP_Text costText;
        [SerializeField] private CanvasGroup canvasGroup;

        private int towerId;
        private Action<int> clicked;

        public int TowerId => towerId;

        public void Init(TdTowerUiConfig config, Action<int> onClicked)
        {
            towerId = config.Id;
            clicked = onClicked;
            if (iconImage != null)
            {
                iconImage.sprite = config.Icon;
            }
            if (nameText != null)
            {
                nameText.text = config.Name;
            }
            if (costText != null)
            {
                costText.text = config.Cost.ToString();
            }
            if (button != null)
            {
                button.onClick.RemoveAllListeners();
                button.onClick.AddListener(OnClick);
            }
        }

        public void SetSelected(bool selected)
        {
            if (selectedFrame != null)
            {
                selectedFrame.gameObject.SetActive(selected);
            }
        }

        public void SetInteractable(bool value)
        {
            if (button != null)
            {
                button.interactable = value;
            }
            if (canvasGroup != null)
            {
                canvasGroup.alpha = value ? 1f : 0.45f;
            }
        }

        private void OnClick()
        {
            clicked?.Invoke(towerId);
        }
    }
}
